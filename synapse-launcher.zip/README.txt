Welcome to Synapse! We are glad to have you here.

To start, run Synapse Launcher.exe.

If you need any help, you can contact our support team at https://discord.gg/3PwAy6Zy2D.

Enjoy!